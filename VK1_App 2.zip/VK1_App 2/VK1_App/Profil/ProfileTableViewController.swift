//
//  ProfileTableViewController.swift
//  Lesson1_LA
//
//  Created by Анатолий Левин on 04.03.2021.
//

import UIKit

class ProfileTableViewController: UITableViewController {
    @IBAction  func plusAction( sender: UIBarButtonItem) {
        print ("Plus button tapped")
    }

}
