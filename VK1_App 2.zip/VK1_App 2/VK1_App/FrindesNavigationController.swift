//
//  FrindesNavigationController.swift
//  
//
//  Created by Анатолий Левин on 16.04.2021.
//

import UIKit

class FrindesNavigationController: UINavigationController {

}
