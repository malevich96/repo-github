//
//  ViewController.swift
//  VK1_App
//
//  Created by Анатолий Левин on 19.03.2021.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
